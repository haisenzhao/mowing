//
//  Vector.cpp
//  ToolPathTimeEstimator
//
//  Created by Celr on 15/12/10.
//  Copyright © 2015年 Celr. All rights reserved.
//
#include "StdAfx.h"
#include "Vector.hpp"
