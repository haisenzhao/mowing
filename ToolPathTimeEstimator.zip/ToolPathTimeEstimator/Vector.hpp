//
//  Vector.hpp
//  ToolPathTimeEstimator
//
//  Created by Celr on 15/12/10.
//  Copyright © 2015年 Celr. All rights reserved.
//

#ifndef Vector_hpp
#define Vector_hpp

#include <stdio.h>

#endif /* Vector_hpp */
